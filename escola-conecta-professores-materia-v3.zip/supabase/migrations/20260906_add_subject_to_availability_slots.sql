-- Vincula cada horário disponível a uma matéria cadastrada pelo professor.
-- Execute esta migration no Supabase antes de publicar a versão nova da agenda.

alter table public.availability_slots
  add column if not exists subject text;

create index if not exists availability_slots_subject_idx
  on public.availability_slots (subject);

comment on column public.availability_slots.subject is
  'Matéria escolhida pelo professor para este horário de aula.';
